<?php

//$plugins["PLUGIN_NAME"]["enabled"] = 1;



?>