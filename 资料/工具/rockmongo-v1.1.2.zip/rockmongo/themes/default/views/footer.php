
<?php render_page_footer(); ?>
</body>
</html>